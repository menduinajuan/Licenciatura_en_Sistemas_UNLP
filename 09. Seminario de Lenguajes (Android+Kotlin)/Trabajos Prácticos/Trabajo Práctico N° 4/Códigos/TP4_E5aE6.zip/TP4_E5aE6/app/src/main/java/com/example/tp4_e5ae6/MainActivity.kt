package com.example.tp4_e5ae6

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var textCounter: TextView
    private lateinit var btnToggle: Button
    private var counter = 0
    private var isRunning = true
    private var isRedPhase = false
    private val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                if (!isRedPhase) {
                    textCounter.setTextColor(Color.RED)
                    isRedPhase = true
                }
                else {
                    counter++
                    textCounter.text = counter.toString()
                    textCounter.setTextColor(Color.BLACK)
                    isRedPhase = false
                }
                handler.postDelayed(this, 500)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        textCounter = findViewById(R.id.textCounter)
        btnToggle = findViewById(R.id.btnToggle)
        handler.post(runnable)
        btnToggle.setOnClickListener {
            isRunning = !isRunning
            if (isRunning) {
                btnToggle.text = getString(R.string.btn_stop)
                handler.post(runnable)
            }
            else {
                btnToggle.text = getString(R.string.btn_start)
                handler.removeCallbacks(runnable)
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable)
    }
}