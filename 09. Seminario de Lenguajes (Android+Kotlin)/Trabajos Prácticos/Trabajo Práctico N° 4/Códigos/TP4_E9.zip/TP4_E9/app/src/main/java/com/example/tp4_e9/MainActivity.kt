package com.example.tp4_e9

import android.icu.util.Calendar
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private val imagenes = arrayOf(
        R.drawable.facultad_informatica_1,
        R.drawable.facultad_informatica_2,
        R.drawable.facultad_informatica_3
    )
    private lateinit var imgViewFacultad: ImageView
    private var index = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1
        if (hour in 10..22) {
            setTheme(R.style.dia)
        }
        else {
            setTheme(R.style.noche)
        }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val toolbar = findViewById<Toolbar?>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        imgViewFacultad = findViewById(R.id.imgViewFacultad)
        mostrarImagenActual()
        val menuHost: MenuHost = this
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_ppal, menu)
            }
            override fun onMenuItemSelected(item: MenuItem): Boolean {
                return when (item.itemId) {
                    R.id.menuSiguiente -> {
                        mostrarImagenSiguiente()
                        true
                    }
                    R.id.menuAnterior -> {
                        mostrarImagenAnterior()
                        true
                    }
                    else -> false
                }
            }
        }, this)
    }
    private fun mostrarImagenActual() {
        imgViewFacultad.setImageResource(imagenes[index])
    }
    private fun mostrarImagenSiguiente() {
        index = (index + 1) % imagenes.size
        mostrarImagenActual()
    }
    private fun mostrarImagenAnterior() {
        index = if (index - 1 < 0) imagenes.size - 1 else index - 1
        mostrarImagenActual()
    }
}