package com.example.tp3_e2ae4

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private val imagenes = arrayOf(
        R.drawable.facultad_informatica_1,
        R.drawable.facultad_informatica_2,
        R.drawable.facultad_informatica_3
    )
    private var index = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val imgViewFacultad = findViewById<ImageView?>(R.id.imgViewFacultad)
        val btnSiguiente = findViewById<Button?>(R.id.btnSiguiente)
        val btn1 = findViewById<Button?>(R.id.btn1)
        val btn2 = findViewById<Button?>(R.id.btn2)
        val btn3 = findViewById<Button?>(R.id.btn3)
        if (savedInstanceState != null) {
            index = savedInstanceState.getInt("index")
        }
        imgViewFacultad?.setImageResource(imagenes[index])
        btnSiguiente?.setOnClickListener {
            index = (index + 1) % imagenes.size
            imgViewFacultad?.setImageResource(imagenes[index])
        }
        btn1?.setOnClickListener {
            index = 0
            imgViewFacultad?.setImageResource(imagenes[index])
        }
        btn2?.setOnClickListener {
            index = 1
            imgViewFacultad?.setImageResource(imagenes[index])
        }
        btn3?.setOnClickListener {
            index = 2
            imgViewFacultad?.setImageResource(imagenes[index])
        }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("index", index);
    }
}