package com.example.minibatallanaval

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    // VARIABLES DE INSTANCIA CONSTANTES
    private val barcosMin = 10
    private val barcosMax = 15

    // VARIABLES DE INSTANCIA NO PRIMITIVAS
    private lateinit var tablero: GridLayout
    private lateinit var board: Array<Array<String>>
    private lateinit var txtMovimientos: TextView
    private lateinit var txtAciertos: TextView
    private lateinit var txtRestantes: TextView
    private lateinit var btnReiniciar: Button
    private lateinit var toolbar: Toolbar

    // VARIABLES DE INSTANCIA PRIMITIVAS
    private var jugador = ""
    private var rows = 0
    private var cols = 0
    private var juegoTerminado = false
    private var totalBarcos = 0
    private var movimientos = 0
    private var aciertos = 0

    // FUNCIÓN ONCREATE()
    override fun onCreate(savedInstanceState: Bundle?) {

        // Configuración del tema
        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setTheme(R.style.Theme_Vertical)
        }
        else {
            setTheme(R.style.Theme_Horizontal)
        }

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a los elementos del Layout
        tablero = findViewById(R.id.tablero)
        txtMovimientos = findViewById(R.id.txtMovimientos)
        txtAciertos = findViewById(R.id.txtAciertos)
        txtRestantes = findViewById(R.id.txtRestantes)
        btnReiniciar = findViewById(R.id.btnReiniciar)
        toolbar = findViewById(R.id.toolbar)

        // Inicio del juego
        if (savedInstanceState == null) {
            iniciarJuego()
        }
        // Restauración del juego (si fue previamente iniciado)
        else {
            restaurarJuego(savedInstanceState)
        }

        // Reinicio del juego (si fue tocado el botón de reinicio)
        btnReiniciar.setOnClickListener {
            reinicarJuego()
        }

        // Menú PopUp
        menuPopUp()

    }

    // FUNCIÓN "onSaveInstanceState"
    override fun onSaveInstanceState(outState: Bundle) {

        super.onSaveInstanceState(outState)

        // Guardado de los valores de las variables
        outState.putString("jugador", jugador)
        outState.putInt("rows", rows)
        outState.putInt("cols", cols)
        outState.putBoolean("juegoTerminado", juegoTerminado)
        outState.putInt("totalBarcos", totalBarcos)
        outState.putInt("movimientos", movimientos)
        outState.putInt("aciertos", aciertos)

        // Guardado del tablero
        val boardPlano = board.flatten().toTypedArray()
        outState.putStringArray("board", boardPlano)
        val botonesTocados = mutableListOf<String>()
        for (i in 0 until rows) {
            for (j in 0 until cols) {
                val index = i * cols + j
                val view = tablero.getChildAt(index) as? Button
                if (view != null && !view.isEnabled) {
                    botonesTocados.add("$i,$j:${view.text}")
                }
            }
        }
        outState.putStringArrayList("botonesTocados", ArrayList(botonesTocados))

    }

    // FUNCIÓN "menuPopUp"
    private fun menuPopUp() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        val menuHost: MenuHost = this
        menuHost.addMenuProvider(
        object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_ppal, menu)
            }
            override fun onMenuItemSelected(item: MenuItem): Boolean {
                return when (item.itemId) {
                    R.id.pantallaPrincipal -> {
                        val intent = Intent(this@MainActivity, StartActivity::class.java)
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        startActivity(intent)
                        finish()
                        true
                    }
                    R.id.pantallaAyuda -> {
                        val intent = Intent(this@MainActivity, HelpActivity::class.java)
                        startActivity(intent)
                        true
                    }
                    else -> false
                }
            }
        }, this)
    }

    // FUNCIÓN QUE ACTUALIZA LOS TEXTVIEWS
    private fun actualizarTextViews() {
        txtMovimientos.text = getString(R.string.movimientos) + ": $movimientos"                                        // Inicialización del TextView "txtMovimientos"
        txtAciertos.text = getString(R.string.aciertos) + ": $aciertos"                                              // Inicialización del TextView "txtAciertos"
        txtRestantes.text = getString(R.string.restantes) + ": ${totalBarcos - aciertos}"                             // Inicialización del TextView "txtRestantes"
    }

    // FUNCIÓN QUE INICIA EL JUEGO
    private fun iniciarJuego() {
        // Inicialización de los contadores
        movimientos = 0; aciertos = 0
        // Valores de las variables obtenidos del Intent
        jugador = intent.getStringExtra("JUGADOR") ?: "Jugador"
        rows = intent.getIntExtra("ROWS", 6)
        cols = intent.getIntExtra("COLS", 6)
        generarTablero()                                                                            // Invocación a la función generarTablero()
        actualizarTextViews()                                                                       // Iniciliazación de los TextViews
        mostrarTablero()                                                                            // Invocación a la función mostrarTablero()
    }

    // FUNCIÓN QUE RESTAURA EL JUEGO
    private fun restaurarJuego(savedInstanceState: Bundle) {

        // Restauración de las variables
        jugador = savedInstanceState.getString("jugador") ?: "Jugador"
        rows = savedInstanceState.getInt("rows")
        cols = savedInstanceState.getInt("cols")
        juegoTerminado = savedInstanceState.getBoolean("juegoTerminado")
        totalBarcos = savedInstanceState.getInt("totalBarcos")
        movimientos = savedInstanceState.getInt("movimientos")
        aciertos = savedInstanceState.getInt("aciertos")

        // Restauración del tablero
        mostrarTablero()
        val boardPlano = savedInstanceState.getStringArray("board")
        board = Array(rows) { i -> Array(cols) { j -> boardPlano?.get(i * cols + j) ?: "agua" } }
        val botonesTocados = savedInstanceState.getStringArrayList("botonesTocados")
        botonesTocados?.forEach { info ->
            val (coord, emoji) = info.split(":")
            val (i, j) = coord.split(",").map { it.toInt() }
            val index = i * cols + j
            val boton = tablero.getChildAt(index) as? Button
            boton?.apply {
                isEnabled = false
                text = emoji
                setBackgroundColor(if (text == "🚢") Color.RED else Color.BLUE)
                setTextColor(Color.WHITE)
            }
        }

        // Restauración de los TextViews
        actualizarTextViews()

    }

    // FUNCIÓN QUE REINICIA EL JUEGO
    private fun reinicarJuego() {
        if (juegoTerminado) {
            juegoTerminado = false
        }
        iniciarJuego()
    }

    // FUNCIÓN QUE GENERA EL TABLERO
    private fun generarTablero() {
        board = Array(rows) { Array(cols) { "agua" } }                                              // Creación del tablero vacío, como una matriz de Strings con dimensión (rows, cols)
        totalBarcos = (barcosMin..barcosMax).random()                                         // Generación de la cantidad aleatoria de barcos, entre barcosMin y barcosMax
        var barcosColocados = 0                                                                     // Colocación de los barcos en posiciones aleatorias del tablero
        while (barcosColocados < totalBarcos) {
            val i = (0 until rows).random()
            val j = (0 until cols).random()
            if (board[i][j] == "agua") {
                board[i][j] = "barco"
                barcosColocados++
            }
        }
    }

    // FUNCIÓN QUE MUESTRA EL TABLERO
    private fun mostrarTablero() {

        tablero.removeAllViews()                                                                    // Eliminación de los botones que pudiera haber si se viene de una partida anterior
        tablero.rowCount = rows; tablero.columnCount = cols;                                        // Configuración del tablero para que tenga dimensión (rows, cols)

        // Creación de un botón para cada posición (i, j) del tablero
        for (i in 0 until rows) {
            for (j in 0 until cols) {

                // Creación del botón en la posición (i, j) del tablero
                val boton = Button(this).apply {

                    // Configuración del botón
                    val params = GridLayout.LayoutParams().apply {
                        width = 0
                        height = 0
                        rowSpec = GridLayout.spec(i, 1f)
                        columnSpec = GridLayout.spec(j, 1f)
                        setMargins(4, 4, 4, 4)
                    }
                    layoutParams = params
                    text = ""
                    setBackgroundColor(Color.BLACK)
                    setTextColor(Color.WHITE)

                    // Acciones al tocar el botón
                    setOnClickListener {

                        // Si el juego terminó, no se permite seguir clickeando celdas vacías
                        if (juegoTerminado) return@setOnClickListener

                        // Suma 1 a la variable "movimientos"
                        movimientos++

                        // Si es barco, cambia el fondo a rojo, muestra un emoji de barco y suma 1 a la variable "aciertos"
                        if (board[i][j] == "barco") {
                            text = "🚢"
                            setBackgroundColor(Color.RED)
                            aciertos++
                        }
                        // Si es agua, cambia el fondo a azul y muestra un emoji de agua
                        else {
                            text = "🌊"
                            setBackgroundColor(Color.BLUE)
                        }

                        // Desactivación del botón (para no poder hacer click dos veces)
                        isEnabled = false

                        // Actualización de los TextViews
                        actualizarTextViews()

                        // Verificación de terminación de juego
                        if (aciertos == totalBarcos) {
                            juegoTerminado = true
                            Toast.makeText(context, "¡Juego terminado!", Toast.LENGTH_SHORT).show()
                            Toast.makeText(context, "ESTADÍSTICAS FINALES de $jugador:\n$aciertos aciertos y ${movimientos - aciertos} agua", Toast.LENGTH_LONG).show()
                        }

                    }

                }

                // Agregar el botón al GridLayout
                tablero.addView(boton)

            }
        }

    }

}