package com.example.minibatallanaval

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class StartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        // Configuración del tema
        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setTheme(R.style.Theme_Vertical)
        }
        else {
            setTheme(R.style.Theme_Horizontal)
        }

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_start)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a los elementos del Layout
        val etJugador = findViewById<EditText>(R.id.etJugador)
        val spnTamanio = findViewById<Spinner>(R.id.spnTamanio)
        val btnAyuda = findViewById<Button>(R.id.btnAyuda)
        val btnRank = findViewById<Button>(R.id.btnRanking)
        val btnIniciar = findViewById<Button>(R.id.btnIniciar)

        // Opciones para el Spinner
        val tamanios = arrayOf("6x6", "8x8", "10x10")
        spnTamanio.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tamanios)

        // Botón de "Iniciar"
        btnIniciar.setOnClickListener {
            val jugador = etJugador.text.toString()
            val seleccion = spnTamanio.selectedItem.toString()
            val (rows, cols) =
                when (seleccion) {
                    "6x6" -> 6 to 6
                    "8x8" -> 8 to 8
                    "10x10" -> 10 to 10
                    else -> 6 to 6
                }
            if (jugador.isNotBlank()) {
                val intent = Intent(this, MainActivity::class.java).apply {
                    putExtra("JUGADOR", jugador)
                    putExtra("ROWS", rows)
                    putExtra("COLS", cols)
                }
                startActivity(intent)
            }
            else {
                Toast.makeText(this, R.string.aviso_nombre, Toast.LENGTH_SHORT).show()
            }
        }

        // Botón de "Ranking"
        btnRank.setOnClickListener {
            startActivity(Intent(this, RankActivity::class.java))
        }

        // Botón de "Ayuda"
        btnAyuda.setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }

    }

}