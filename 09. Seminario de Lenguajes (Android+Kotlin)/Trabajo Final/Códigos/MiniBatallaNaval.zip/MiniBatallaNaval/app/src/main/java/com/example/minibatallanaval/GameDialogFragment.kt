package com.example.minibatallanaval

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.core.os.bundleOf
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.setFragmentResult

class GameDialogFragment : DialogFragment() {

    // FUNCIÓN "newInstance"
    companion object {
        fun newInstance(tipo: String, aciertos: Int = 0, movimientos: Int = 0): GameDialogFragment {
            return GameDialogFragment().apply {
                arguments = bundleOf(
                    "tipo" to tipo,
                    "aciertos" to aciertos,
                    "movimientos" to movimientos
                )
            }
        }
    }

    // FUNCIÓN "onCreateDialog"
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        super.onCreateDialog(savedInstanceState)
        isCancelable = false

        val args = requireArguments()
        val tipo = args.getString("tipo") ?: return super.onCreateDialog(savedInstanceState)
        val aciertos = args.getInt("aciertos", 0)
        val movimientos = args.getInt("movimientos", 0)

        val appName = getString(R.string.app_name)
        val txtAciertos = getString(R.string.aciertos)
        val txtMovimientos = getString(R.string.movimientos)
        val builder = AlertDialog.Builder(requireContext())

        when (tipo) {

            "tiempoAgotado" -> {
                val mensaje = getString(R.string.tiempo_agotado)
                builder.setTitle(getString(R.string.juego_terminado))
                    .setMessage(mensaje)
                    .setPositiveButton(getString(R.string.reiniciar_juego)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "reiniciarJuego")) }
                    .setNegativeButton(getString(R.string.volver_inicio)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "volverInicio")) }
            }

            "juegoCompletado" -> {
                val mensaje = "🔢 $txtAciertos: $aciertos / $txtMovimientos: $movimientos"
                builder.setTitle(getString(R.string.juego_completado))
                    .setMessage(mensaje)
                    .setPositiveButton(getString(R.string.reiniciar_juego)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "reiniciarJuego")) }
                    .setNegativeButton(getString(R.string.volver_inicio)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "volverInicio")) }
            }

            "juegoRankeado" -> {
                val txtMensaje = getString(R.string.msj_compartido)
                val mensaje = "🔢 $txtAciertos: $aciertos / $txtMovimientos: $movimientos"
                builder.setTitle(getString(R.string.juego_ranking))
                    .setMessage(mensaje)
                    .setPositiveButton(getString(R.string.abrir_ranking)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "abrirRanking")) }
                    .setNegativeButton(getString(R.string.reiniciar_juego)) { dialog, which ->
                        setFragmentResult("clave_alerta", bundleOf("accion" to "reiniciarJuego")) }
                    .setNeutralButton(R.string.compartir) { dialog, which ->
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            val mensajeCompartir = "¡$txtMensaje $appName!\n$txtAciertos: $aciertos / $txtMovimientos: $movimientos"
                            putExtra(Intent.EXTRA_TEXT, mensajeCompartir)
                        }
                        startActivity(Intent.createChooser(shareIntent, "compartir")) }
            }

        }

        return builder.create()

    }

}