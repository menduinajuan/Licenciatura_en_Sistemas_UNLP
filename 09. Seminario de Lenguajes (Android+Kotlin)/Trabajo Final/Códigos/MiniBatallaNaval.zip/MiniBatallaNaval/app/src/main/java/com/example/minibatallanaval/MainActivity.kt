package com.example.minibatallanaval

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import kotlin.collections.*

class MainActivity : AppCompatActivity() {

    // VARIABLES DE INSTANCIA CONSTANTES
    private val barcosMin = 10
    private val barcosMax = 15
    private val tamanioRanking = 5
    private val tiposDialog = arrayOf("tiempoAgotado", "juegoCompletado", "juegoRankeado")
    private val handler = Handler(Looper.getMainLooper())

    // VARIABLES DE INSTANCIA NO PRIMITIVAS
    private lateinit var tablero: GridLayout
    private lateinit var board: Array<Array<String>>
    private lateinit var ranking: Array<Pair<String, Double>>
    private lateinit var txtJugador: TextView
    private lateinit var txtTiempo: TextView
    private lateinit var txtMovimientos: TextView
    private lateinit var txtAciertos: TextView
    private lateinit var txtRestantes: TextView
    private lateinit var btnReiniciar: Button
    private lateinit var toolbar: Toolbar
    private lateinit var tiempoRunnable: Runnable

    // VARIABLES DE INSTANCIA PRIMITIVAS
    private var jugador = ""
    private var tiempo = 20L
    private var juegoTerminado = false
    private var rows = 0
    private var cols = 0
    private var totalBarcos = 0
    private var movimientos = 0
    private var aciertos = 0
    private var puntajes = 0

    // FUNCIÓN "onCreate"
    override fun onCreate(savedInstanceState: Bundle?) {

        // Configuración del tema
        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setTheme(R.style.Theme_Vertical)
        }
        else {
            setTheme(R.style.Theme_Horizontal)
        }

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a los elementos del Layout
        tablero = findViewById(R.id.tablero)
        txtJugador = findViewById(R.id.txtJugador)
        txtTiempo = findViewById(R.id.txtTiempo)
        txtMovimientos = findViewById(R.id.txtMovimientos)
        txtAciertos = findViewById(R.id.txtAciertos)
        txtRestantes = findViewById(R.id.txtRestantes)
        btnReiniciar = findViewById(R.id.btnReiniciar)
        toolbar = findViewById(R.id.toolbar)

        // Reseteo del ranking (descomentar si se desea resetear el ranking al iniciar esta activity y, luego, volver a comentar)
        //resetearRanking()

        // Inicio del ranking
        iniciarRanking()

        // Inicio del juego
        if (savedInstanceState == null) {
            iniciarJuego()
        }
        // Restauración del juego (si fue previamente iniciado)
        else {
            restaurarJuego(savedInstanceState)
        }

        // Reinicio del juego (si fue tocado el botón de reinicio)
        btnReiniciar.setOnClickListener {
            reiniciarJuego()
        }

        // Menú PopUp
        menuPopUp()

        // Fragment Manager
        fragmentManager()

    }

    // FUNCIÓN "onSaveInstanceState"
    override fun onSaveInstanceState(outState: Bundle) {

        super.onSaveInstanceState(outState)

        // Guardado de los valores de las variables
        outState.putString("jugador", jugador)
        outState.putLong("tiempo", tiempo)
        outState.putBoolean("juegoTerminado", juegoTerminado)
        outState.putInt("rows", rows)
        outState.putInt("cols", cols)
        outState.putInt("totalBarcos", totalBarcos)
        outState.putInt("movimientos", movimientos)
        outState.putInt("aciertos", aciertos)
        outState.putInt("puntajes", puntajes)

        // Guardado del tablero
        val boardPlano = board.flatten().toTypedArray()
        outState.putStringArray("board", boardPlano)
        val botonesTocados = mutableListOf<String>()
        for (i in 0 until rows) {
            for (j in 0 until cols) {
                val index = i * cols + j
                val view = tablero.getChildAt(index) as? Button
                if (view != null && !view.isEnabled) {
                    botonesTocados.add("$i,$j:${view.text}")
                }
            }
        }
        outState.putStringArrayList("botonesTocados", ArrayList(botonesTocados))

        // Detenimiento del temporizador
        detenerTemporizador()

    }

    // FUNCIÓN "menuPopUp"
    private fun menuPopUp() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        val menuHost: MenuHost = this
        menuHost.addMenuProvider(
            object : MenuProvider {
                override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                    menuInflater.inflate(R.menu.menu_ppal, menu)
                }
                override fun onMenuItemSelected(item: MenuItem): Boolean {
                    return when (item.itemId) {
                        R.id.pantallaInicio -> {
                            val intent = Intent(this@MainActivity, StartActivity::class.java)
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(intent)
                            finish()
                            true
                        }
                        R.id.pantallaAyuda -> {
                            val intent = Intent(this@MainActivity, HelpActivity::class.java)
                            startActivity(intent)
                            true
                        }
                        else -> false
                    }
                }
            }, this)
    }

    // FUNCIÓN "fragmentManager"
    private fun fragmentManager() {
        supportFragmentManager.setFragmentResultListener("clave_alerta", this) { requestKey, bundle ->
            val resultado = bundle.getString("accion")
            when (resultado) {
                "reiniciarJuego" -> {
                    reiniciarJuego()
                }
                "volverInicio" -> {
                    val intent = Intent(this@MainActivity, StartActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivity(intent)
                    finish()
                }
                "abrirRanking" -> {
                    startActivity(Intent(this@MainActivity, RankActivity::class.java))
                    finish()
                }
            }
        }
    }

    // FUNCIÓN QUE RESETEA EL RANKING
    private fun resetearRanking() {
        ranking = Array(tamanioRanking) { Pair("", Double.MIN_VALUE) }
        val sharedPreferences = getSharedPreferences("ranking_prefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        for (i in 0 until tamanioRanking) {
            editor.remove("name_$i")
            editor.remove("score_$i")
        }
        editor.apply()
    }

    // FUNCIÓN QUE INICIA EL RANKING
    private fun iniciarRanking() {
        ranking = Array(tamanioRanking) { Pair("", Double.MIN_VALUE) }
        val rankingRecuperado = recuperarRanking()
        for (i in rankingRecuperado.indices) {
            val nombre = rankingRecuperado[i].first
            val puntaje = rankingRecuperado[i].second.toDoubleOrNull() ?: Double.MIN_VALUE
            ranking[i] = Pair(nombre, puntaje)
            if (ranking[i].second != Double.MIN_VALUE) {
                puntajes++
            }
        }
    }

    // FUNCIÓN QUE RECUPERA EL RANKING
    private fun recuperarRanking(): List<Pair<String, String>> {
        val sharedPreferences = getSharedPreferences("ranking_prefs", Context.MODE_PRIVATE)
        val rankingRecuperado = mutableListOf<Pair<String, String>>()
        for (i in 0 until tamanioRanking) {
            val nombre = sharedPreferences.getString("name_$i", null)
            val puntaje = sharedPreferences.getString("score_$i", null)
            if (nombre != null && puntaje != null) {
                rankingRecuperado.add(Pair(nombre, puntaje))
            }
        }
        return rankingRecuperado
    }

    // FUNCIÓN QUE INICIA EL JUEGO
    private fun iniciarJuego() {

        // Inicialización de las variables
        juegoTerminado = false; movimientos = 0; aciertos = 0

        // Valores de las variables obtenidos del Intent
        jugador = intent.getStringExtra("JUGADOR") ?: "Jugador"
        rows = intent.getIntExtra("ROWS", 6)
        cols = intent.getIntExtra("COLS", 6)

        // Inicialización del temporarizador
        tiempo = when {
            rows == 6 && cols == 6 -> 20L
            rows == 8 && cols == 8 -> 25L
            else -> 30L
        }

        // Invocación a diferentes funciones
        generarTablero()
        actualizarTextViews()
        mostrarTablero()

    }

    // FUNCIÓN QUE RESTAURA EL JUEGO
    private fun restaurarJuego(savedInstanceState: Bundle) {

        // Restauración de las variables
        jugador = savedInstanceState.getString("jugador") ?: "Jugador"
        tiempo = savedInstanceState.getLong("tiempo")
        juegoTerminado = savedInstanceState.getBoolean("juegoTerminado")
        rows = savedInstanceState.getInt("rows")
        cols = savedInstanceState.getInt("cols")
        totalBarcos = savedInstanceState.getInt("totalBarcos")
        movimientos = savedInstanceState.getInt("movimientos")
        aciertos = savedInstanceState.getInt("aciertos")
        puntajes = savedInstanceState.getInt("puntajes")

        // Restauración del tablero
        mostrarTablero()
        val boardPlano = savedInstanceState.getStringArray("board")
        board = Array(rows) { i -> Array(cols) { j -> boardPlano?.get(i * cols + j) ?: "agua" } }
        val botonesTocados = savedInstanceState.getStringArrayList("botonesTocados")
        botonesTocados?.forEach { info ->
            val (coord, emoji) = info.split(":")
            val (i, j) = coord.split(",").map { it.toInt() }
            val index = i * cols + j
            val boton = tablero.getChildAt(index) as? Button
            boton?.apply {
                isEnabled = false
                text = emoji
                setBackgroundColor(if (text == "🚢") Color.RED else Color.BLUE)
                setTextColor(Color.WHITE)
            }
        }

        // Restauración de los TextViews
        actualizarTextViews()

    }

    // FUNCIÓN QUE REINICIA EL JUEGO
    private fun reiniciarJuego() {
        detenerTemporizador()
        iniciarTemporizador()
        iniciarJuego()
    }

    // FUNCIÓN QUE GENERA EL TABLERO
    private fun generarTablero() {

        // Creación del tablero vacío, como una matriz de Strings con dimensión (rows, cols)
        board = Array(rows) { Array(cols) { "agua" } }

        // Generación de la cantidad aleatoria de barcos, entre barcosMin y barcosMax
        totalBarcos = (barcosMin..barcosMax).random()

        // Colocación de los barcos en posiciones aleatorias del tablero
        var barcosColocados = 0
        while (barcosColocados < totalBarcos) {
            val i = (0 until rows).random()
            val j = (0 until cols).random()
            if (board[i][j] == "agua") {
                board[i][j] = "barco"
                barcosColocados++
            }
        }

    }

    // FUNCIÓN QUE ACTUALIZA LOS TEXTVIEWS
    private fun actualizarTextViews() {
        txtJugador.text = getString(R.string.jugador) + ": $jugador"
        txtTiempo.text = getString(R.string.tiempo) + ": $tiempo"
        txtMovimientos.text = getString(R.string.movimientos) + ": $movimientos"
        txtAciertos.text = getString(R.string.aciertos) + ": $aciertos"
        txtRestantes.text = getString(R.string.restantes) + ": ${totalBarcos - aciertos}"
    }

    // FUNCIÓN QUE MUESTRA EL TABLERO
    private fun mostrarTablero() {

        // Eliminación de los botones que pudiera haber si se viene de una partida anterior
        tablero.removeAllViews()

        // Configuración del tablero para que tenga dimensión (rows, cols)
        tablero.rowCount = rows; tablero.columnCount = cols

        // Creación de un botón para cada posición (i, j) del tablero
        for (i in 0 until rows) {
            for (j in 0 until cols) {

                // Creación del botón en la posición (i, j) del tablero
                val boton = Button(this).apply {

                    // Configuración del botón
                    val params = GridLayout.LayoutParams().apply {
                        width = 0
                        height = 0
                        rowSpec = GridLayout.spec(i, 1f)
                        columnSpec = GridLayout.spec(j, 1f)
                        setMargins(4, 4, 4, 4)
                    }
                    layoutParams = params
                    text = ""
                    setBackgroundColor(Color.BLACK)
                    setTextColor(Color.WHITE)

                    // Acciones al tocar el botón
                    setOnClickListener {

                        // Si el juego terminó, no se permite seguir clickeando celdas vacías
                        if (juegoTerminado) return@setOnClickListener

                        // Suma 1 a la variable "movimientos"
                        movimientos++

                        // Si es barco, cambia el fondo a rojo, muestra un emoji de barco y suma 1 a la variable "aciertos"
                        if (board[i][j] == "barco") {
                            text = "🚢"
                            setBackgroundColor(Color.RED)
                            aciertos++
                        }
                        // Si es agua, cambia el fondo a azul y muestra un emoji de agua
                        else {
                            text = "🌊"
                            setBackgroundColor(Color.BLUE)
                        }

                        // Desactivación del botón (para no poder hacer click dos veces)
                        isEnabled = false

                        // Actualización de los TextViews
                        actualizarTextViews()

                        // Verificación de terminación de juego
                        if (aciertos == totalBarcos) {
                            juegoTerminado = true
                            detenerTemporizador()
                            val nuevoPuntaje = String.format(Locale.US, "%.3f", aciertos.toDouble() / movimientos.toDouble()).toDouble()
                            if (actualizarRanking(nuevoPuntaje)) {
                                if (supportFragmentManager.findFragmentByTag("GameDialog") == null) {
                                    GameDialogFragment.newInstance(tiposDialog[2], aciertos, movimientos).show(supportFragmentManager, "GameDialog")
                                }
                            }
                            else {
                                if (supportFragmentManager.findFragmentByTag("GameDialog") == null) {
                                    GameDialogFragment.newInstance(tiposDialog[1], aciertos, movimientos).show(supportFragmentManager, "GameDialog")
                                }
                            }
                        }

                    }

                }

                // Agregar el botón al GridLayout
                tablero.addView(boton)

            }
        }

    }

    // FUNCIÓN QUE INICIA EL TEMPORIZADOR
    private fun iniciarTemporizador() {
        tiempoRunnable = Runnable {
            if (!juegoTerminado) {
                if (tiempo > 0) {
                    tiempo--
                    actualizarTextViews()
                    handler.postDelayed(tiempoRunnable, 1000)
                }
                else {
                    juegoTerminado = true
                    desactivarBotones()
                    if (supportFragmentManager.findFragmentByTag("GameDialog") == null) {
                        GameDialogFragment.newInstance(tiposDialog[0]).show(supportFragmentManager, "GameDialog")
                    }
                }
            }
        }
        handler.postDelayed(tiempoRunnable, 1000)
    }

    // FUNCIÓN QUE DESACTIVA LOS BOTONES DEL TABLERO
    private fun desactivarBotones() {
        for (i in 0 until rows * cols) {
            val button = tablero.getChildAt(i) as? Button
            button?.isEnabled = false
        }
    }

    // FUNCIÓN QUE DETIENE EL TEMPORIZADOR
    private fun detenerTemporizador() {
        handler.removeCallbacks(tiempoRunnable)
    }

    // FUNCIÓN QUE ACTUALIZA EL RANKING
    private fun actualizarRanking(nuevoPuntaje: Double): Boolean {

        var enRanking = false
        val sharedPreferences = getSharedPreferences("ranking_prefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        // Guardado del puntaje en la variable "ranking"
        if (puntajes < tamanioRanking) {
            ranking[puntajes++] = Pair(jugador, nuevoPuntaje)
            ranking.sortByDescending { it.second }
            enRanking = true
        }
        else if (nuevoPuntaje > ranking.last().second) {
            ranking[ranking.size - 1] = Pair(jugador, nuevoPuntaje)
            ranking.sortByDescending { it.second }
            enRanking = true
        }

        // Guardado del ranking en SharedPreferences
        for (i in 0 until tamanioRanking) {
            if (ranking[i].second != Double.MIN_VALUE) {
                val nombre = ranking[i].first
                val puntaje = ranking[i].second
                editor.putString("name_$i", nombre)
                editor.putString("score_$i", String.format(Locale.US, "%.3f", puntaje))
            }
        }

        editor.apply()
        return enRanking

    }

    // FUNCIÓN "onResume"
    override fun onResume() {
        super.onResume()
        if (!juegoTerminado) {
            iniciarTemporizador()
        }
    }

    // FUNCIÓN "onPause"
    override fun onPause() {
        super.onPause()
        if (!juegoTerminado) {
            detenerTemporizador()
        }
    }

    // FUNCIÓN "onDestroy"
    override fun onDestroy() {
        super.onDestroy()
        detenerTemporizador()
    }

}