package com.example.minibatallanaval

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RankActivity : AppCompatActivity() {

    // VARIABLES DE INSTANCIA CONSTANTES
     private val tamanioRanking = 5

    // VARIABLES DE INSTANCIA NO PRIMITIVAS
    private lateinit var txtScore1: TextView
    private lateinit var txtScore2: TextView
    private lateinit var txtScore3: TextView
    private lateinit var txtScore4: TextView
    private lateinit var txtScore5: TextView
    private lateinit var btnVolver: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        // Configuración del tema
        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            setTheme(R.style.Theme_Vertical)
        }
        else {
            setTheme(R.style.Theme_Horizontal)
        }

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_rank)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Referencias a los elementos del Layout
        txtScore1 = findViewById(R.id.txtScore1)
        txtScore2 = findViewById(R.id.txtScore2)
        txtScore3 = findViewById(R.id.txtScore3)
        txtScore4 = findViewById(R.id.txtScore4)
        txtScore5 = findViewById(R.id.txtScore5)
        btnVolver = findViewById(R.id.btnVolver)

        // Muestra del ranking
        mostrarRanking()

        // Botón de "Volver"
        btnVolver.setOnClickListener {
            finish()
        }

    }

    // FUNCIÓN QUE MUESTRA EL RANKING
    private fun mostrarRanking() {
        val ranking = recuperarRanking()
        val textViews = listOf(txtScore1, txtScore2, txtScore3, txtScore4, txtScore5)
        for (i in textViews.indices) {
            val par = ranking.getOrNull(i)
            textViews[i].text = par?.let { (nombre, puntaje) -> "${i + 1}. $nombre ($puntaje)" } ?: "${i + 1}. -"
        }
    }

    // FUNCIÓN QUE RECUPERA EL RANKING
    private fun recuperarRanking(): List<Pair<String, String>> {
        val sharedPreferences = getSharedPreferences("ranking_prefs", Context.MODE_PRIVATE)
        val rankingRecuperado = mutableListOf<Pair<String, String>>()
        for (i in 0 until tamanioRanking) {
            val nombre = sharedPreferences.getString("name_$i", null)
            val puntaje = sharedPreferences.getString("score_$i", null)
            if (nombre != null && puntaje != null) {
                rankingRecuperado.add(Pair(nombre, puntaje))
            }
        }
        return rankingRecuperado
    }

}